@extends('layouts.app')

@section('title', 'Shopping Cart')

@section('content')
<div class="container py-5">
    <h2 class="mb-4">Shopping Cart</h2>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="cart-items">
                @forelse ($purchases as $item)
                    <div class="cart-item" style="border-bottom: 1px solid #eee; margin-bottom: 15px; padding-bottom: 15px;">
                        <div class="row align-items-center">
                            <div class="col-md-2">
                                <img src="{{ $item->product->image }}" alt="{{ $item->product->name }}"
                                     class="img-fluid rounded"
                                     style="width: 60px; height: 60px; object-fit: contain;">
                            </div>
                            <div class="col-md-4">
                                <h5 class="mb-1">{{ $item->product->name }}</h5>
                                <p class="mb-0">${{ number_format($item->price, 2) }}</p>
                            </div>
                            <div class="col-md-3">
                                <p class="mb-0">Qty: {{ $item->quantity }}</p>
                            </div>
                            <div class="col-md-2 text-end">
                                <p class="mb-0 fw-bold">${{ number_format($item->quantity * $item->price, 2) }}</p>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="text-center p-5">
                        <i class="bi bi-cart-x fs-1 text-muted mb-3"></i>
                        <h4>Your cart is empty</h4>
                        <p class="text-muted">Add some products to your cart and they will appear here.</p>
                        <a href="{{ route('products.index') }}" class="btn btn-primary">Continue Shopping</a>
                    </div>
                @endforelse
            </div>
        </div>

        <div class="col-lg-4">
            <div class="summary-card">
                <h4 class="mb-4">Order Summary</h4>
                <div class="d-flex justify-content-between mb-3">
                    <span>Subtotal</span>
                    <span class="cart-subtotal">
                        ${{ number_format($purchases->sum(fn($item) => $item->price * $item->quantity), 2) }}
                    </span>
                </div>
                <hr class="border-secondary">
                <div class="d-flex justify-content-between mb-4">
                    <strong>Total</strong>
                    <strong class="cart-total">
                        ${{ number_format($purchases->sum(fn($item) => $item->price * $item->quantity), 2) }}
                    </strong>
                </div>
                <button class="btn btn-primary btn-checkout w-100">
                    Proceed to Checkout
                </button>
            </div>
        </div>
    </div>
</div>
@endsection
