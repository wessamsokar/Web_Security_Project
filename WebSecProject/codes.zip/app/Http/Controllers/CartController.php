<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        // Get the pending order for the user
        $order = Order::where('user_id', $user->id)
                      ->where('status', 'pending')
                      ->first();

        if (!$order) {
            $purchases = collect(); // Empty cart
        } else {
            $purchases = $order->purchases()->with('product')->get();
        }

        return view('cart.index', compact('purchases'));
    }

    public function add(Request $request)
    {
        $validated = $request->validate([
            'product_id' => 'required|exists:products,id',
            'size_id' => 'required|exists:sizes,id',
            'quantity' => 'required|integer|min:1',
        ]);

        $user = $request->user();

        // Find or create a pending order for the user
        $order = \App\Models\Order::firstOrCreate(
            ['user_id' => $user->id, 'status' => 'pending'],
            ['total' => 0]
        );

        // Add or update purchase in the order
        $order->purchases()->updateOrCreate(
            [
                'product_id' => $validated['product_id'],
                'size_id' => $validated['size_id'],
            ],
            [
                'quantity' => $validated['quantity'],
                'price' => \App\Models\Product::find($validated['product_id'])->price,
            ]
        );

        return response()->json(['success' => true]);
    }
}
